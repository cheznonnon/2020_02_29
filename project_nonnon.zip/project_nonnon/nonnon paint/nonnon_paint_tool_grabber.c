// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// the base layer

#include "../nonnon/neutral/bmp/all.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_checkbox.c"
#include "../nonnon/win32/win_scroller.c"
#include "../nonnon/win32/win_separator.c"
#include "../nonnon/win32/win_statusbar_ownerdraw.c"

#include "../nonnon/project/macro.c"




// rc.h


#define H_LINE      n_paint_tool_grabber_hgui[ 0 ]
#define GUI_MAX                                1

#define H_CHECK     ( &n_paint_tool_grabber_check  )
#define H_STATUS    ( &n_paint_tool_grabber_status )


#define H_SCR_BLEND ( &n_paint_tool_grabber_hscr[ 0 ] )
#define SCR_MAX                                   1




// window

static HWND                      n_paint_tool_grabber_hgui[ GUI_MAX ];
static n_win_scroller            n_paint_tool_grabber_hscr[ SCR_MAX ];
static n_win_check               n_paint_tool_grabber_check;




void
n_paint_tool_grabber_exit( void )
{

	n_win_stdfont_exit( n_paint_tool_grabber_hgui, GUI_MAX );

	n_win_check_exit( H_CHECK );

	n_win_scroller_exit( H_SCR_BLEND );

	n_win_statusbar_od_exit( H_STATUS );


	return;
}

void
n_paint_tool_grabber_blend_zero( void )
{

	n_paint_tool_blend = H_SCR_BLEND->scrollbar.unit_pos = 0;

	n_win_scroller_scroll_refresh( H_SCR_BLEND );


	return;
}

void
n_paint_tool_grabber_resize( void )
{

	const bool redraw = false;


	s32 ctl, m; n_win_stdsize( hwnd_tool, &ctl, NULL, &m );

	s32 csx  = nwin_tool.csx;
	s32 csy  = nwin_tool.csy;
	s32 line = ctl /  2;

	s32 lx   = ( m * 2 );
	s32 lsx  = nwin_tool.csx - ( m * 4 );

	s32 ssx  = csx - m;

	n_paint_tool_grabber_csy = line + ctl + ctl + ctl + ( m * 2 );


	s32 x = 0;
	s32 y = csy;

	n_win_move_simple    ( H_LINE       , lx,y, lsx,line, redraw ); y += line;
	n_win_move           ( H_CHECK->hwnd,  x,y, csx, ctl, redraw ); y += ctl;
	n_paint_scroller_move( H_SCR_BLEND  ,  x,y, ssx, ctl, redraw ); y += ctl;

	//n_win_statusbar_od_automove( H_STATUS );


	return;
}

void
n_paint_tool_grabber_onoff( bool onoff )
{

	s32 csx = nwin_tool.csx;
	s32 csy = nwin_tool.csy;


	if ( onoff )
	{
//n_win_text_set_literal( hwnd_main, "ON" );

		csy += n_paint_tool_grabber_csy;

		n_win_set( hwnd_tool, NULL, csx,csy, N_WIN_SET_DEFAULT );
		ShowWindow( H_STATUS->hwnd, SW_NORMAL );
		n_win_statusbar_od_automove( H_STATUS );

	} else {
//n_win_text_set_literal( hwnd_main, "OFF" );

		ShowWindow( H_STATUS->hwnd, SW_HIDE );
		n_win_set( hwnd_tool, NULL, csx,csy, N_WIN_SET_DEFAULT );

	}


	return;
}

void
n_paint_tool_grabber_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_SETTINGCHANGE :

		// [!] : XP or later : this message is sent many times

		// [!] : Win8.1 : SPI_SETNONCLIENTMETRICS will never come

		n_win_stdfont_init( n_paint_tool_grabber_hgui, GUI_MAX );

		n_win_scroller_on_settingchange( H_SCR_BLEND );

		n_paint_tool_grabber_resize();

	break;


	case WM_CREATE :


		// Window

		n_win_gui_literal( hwnd, CANVAS, "", &H_LINE      );

		n_win_check_zero( H_CHECK );
		n_win_check_init_literal( H_CHECK, hwnd, "Per-Pixel Alpha Blending", 0 );

		n_win_statusbar_od_zero( H_STATUS );
		n_win_statusbar_od_init( H_STATUS, hwnd, 3 );

		n_win_scroller_zero( H_SCR_BLEND );
		n_win_scroller_init_literal( H_SCR_BLEND, hwnd, "Blend" );


		// Style

		n_win_stdfont_init( n_paint_tool_grabber_hgui, GUI_MAX );


		// Size

		n_paint_tool_grabber_resize();


		// Init

		n_paint_tool_blend = 0;


		// [!] : don't use n_paint_tool_grabber_trans_onoff( false );

		n_win_message_send( hwnd_tool, WM_COMMAND, 0, H_CHECK->hwnd );


		n_win_scroller_scroll_parameter( H_SCR_BLEND, 1, 10, 100, n_paint_tool_blend, true );


		// Display

		n_paint_tool_grabber_onoff( false );

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == H_CHECK->hwnd )
		{

			n_paint_tool_per_pixel_alpha_onoff = n_win_check_is_checked( H_CHECK );

			if ( n_paint_tool_per_pixel_alpha_onoff )
			{
				n_paint_tool_color_transparent = n_paint_tool_color_transparent_get();
			} else {
				n_paint_tool_color_transparent = n_bmp_white;
			}

			n_paint_grabber_resync_auto();


			// [!] : for scroll-wheeler

			SetFocus( hwnd_tool );

		} else

		if ( (HWND) lparam == n_win_scroller_scroll_hwnd( H_SCR_BLEND ) )
		{

			n_paint_tool_blend = wparam;


			n_win_hwndprintf_literal( H_SCR_BLEND->value, "%3d%%", n_paint_tool_blend );


			n_paint_grabber_resync_auto();

		}// else

	break;


	case WM_CLOSE :

		// [!] : never come

	break;


	} // switch


	n_win_separator_proc( hwnd, msg, wparam, lparam, H_LINE, PS_SOLID );

	n_win_check_proc( hwnd, msg, wparam, lparam, H_CHECK );

	n_win_scroller_proc( hwnd, msg, wparam, lparam, H_SCR_BLEND );

	n_win_statusbar_od_proc( hwnd, msg, wparam, lparam, H_STATUS );


	return;
}


#undef H_LINE
#undef GUI_MAX

#undef H_CHECK
#undef H_STATUS

#undef H_SCR_BLEND
#undef SCR_MAX


