// Nekomimi Nina RPG
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#include "./__metric.c"


#include "../nonnon/game/chara.c"




typedef struct {

	n_gdi           gdi;
	n_bmp           bmp;
	n_posix_char    msg[ 100 ];
	s32             x,y,sx,sy;

} n_nnrpg_window;




#define n_nnrpg_window_zero( p ) n_memory_zero( p, sizeof( n_nnrpg_window ) )

void
n_nnrpg_window_bitmap( n_nnrpg_window *p )
{

	n_bmp_free( &p->bmp );


	p->gdi.sx                = p->sx;
	p->gdi.sy                = p->sy;
	p->gdi.style             = N_GDI_SMOOTH;

	p->gdi.base_color_bg     = n_nnrpg_metric.color_window_1;
	p->gdi.base_color_fg     = n_nnrpg_metric.color_window_2;
	p->gdi.base_style        = N_GDI_BASE_VERTICAL;

	p->gdi.frame_style       = N_GDI_FRAME_RPG;
	p->gdi.frame_round       = n_nnrpg_metric.frame_size;
	p->gdi.frame_size        = 1 + n_nnrpg_metric.zoom;

	p->gdi.text              = p->msg;
	p->gdi.text_font         = n_nnrpg_metric.font;
	p->gdi.text_size         = n_nnrpg_metric.textsize;
	p->gdi.text_color_main   = n_bmp_rgb( 255,255,255 );
	p->gdi.text_color_shadow = n_bmp_rgb(  10, 10, 10 );
	p->gdi.text_style        = N_GDI_TEXT_MONOSPACE | N_GDI_TEXT_SHADOW;
	p->gdi.text_fxsize1      = n_nnrpg_metric.zoom;


	n_gdi_bmp( &p->gdi, &p->bmp );


	return;
}

void
n_nnrpg_window_bitmap_frame( n_nnrpg_window *p )
{

	n_bmp_free( &p->bmp );


	p->gdi.sx                = p->sx;
	p->gdi.sy                = p->sy;

	p->gdi.base_color_bg     = n_nnrpg_metric.color_window_1;
	p->gdi.base_color_fg     = n_nnrpg_metric.color_window_2;
	p->gdi.base_style        = N_GDI_BASE_VERTICAL;

	p->gdi.frame_style       = N_GDI_FRAME_RPG;
	p->gdi.frame_round       = n_nnrpg_metric.frame_size;
	p->gdi.frame_size        = 1 + n_nnrpg_metric.zoom;


	n_gdi_bmp( &p->gdi, &p->bmp );


	return;
}

void
n_nnrpg_window_bitmap_text( n_nnrpg_window *p )
{

	n_bmp_free( &p->bmp );


	p->gdi.sx                = p->sx;
	p->gdi.sy                = p->sy;
	p->gdi.style             = N_GDI_SMOOTH;

	p->gdi.text              = p->msg;
	p->gdi.text_font         = n_nnrpg_metric.font;
	p->gdi.text_size         = n_nnrpg_metric.textsize;
	p->gdi.text_color_main   = n_bmp_rgb( 255,255,255 );
	p->gdi.text_color_shadow = n_bmp_rgb(  10, 10, 10 );
	p->gdi.text_style        = N_GDI_TEXT_MONOSPACE | N_GDI_TEXT_SHADOW;
	p->gdi.text_fxsize1      = n_nnrpg_metric.zoom;


	n_gdi_bmp( &p->gdi, &p->bmp );


	return;
}

void
n_nnrpg_window_exit( n_nnrpg_window *p )
{

	n_bmp_free( &p->bmp );

	n_nnrpg_window_zero( p );


	return;
}

void
n_nnrpg_window_init_command( n_nnrpg_window *p )
{

	n_nnrpg_window_exit( p );


	p->x  = n_nnrpg_metric.command_x;
	p->y  = n_nnrpg_metric.command_y;
	p->sx = n_nnrpg_metric.command_sx;
	p->sy = n_nnrpg_metric.command_sy;


	return;
}

void
n_nnrpg_window_init_main( n_nnrpg_window *p )
{

	n_nnrpg_window_exit( p );


	p->x  = n_nnrpg_metric.mainwin_x;
	p->y  = n_nnrpg_metric.mainwin_y;
	p->sx = n_nnrpg_metric.mainwin_sx;
	p->sy = n_nnrpg_metric.mainwin_sy;


	return;
}

void
n_nnrpg_window_erase( n_nnrpg_window *p )
{

	if ( n_bmp_error( &p->bmp ) ) { return; }


	s32 tx = p->x;
	s32 ty = p->y;
	s32 sx = N_BMP_SX( &p->bmp );
	s32 sy = N_BMP_SY( &p->bmp );


	n_bmp_fastcopy( n_nnrpg_metric.bg, n_nnrpg_metric.canvas, tx,ty,sx,sy, tx,ty );


	return;
}

void
n_nnrpg_window_draw( n_nnrpg_window *p )
{

	if ( n_bmp_error( &p->bmp ) ) { return; }


	s32 tx = p->x;
	s32 ty = p->y;
	s32 sx = N_BMP_SX( &p->bmp );
	s32 sy = N_BMP_SY( &p->bmp );


	n_bmp_copy
	(
		&p->bmp, n_nnrpg_metric.canvas, 0,0,sx,sy, tx,ty,
		0.0, 0, 0,
		0//N_BMP_EDGE_ALL
	);


	return;
}




void
n_nnrpg_window_focus( n_nnrpg_window *p, s32 index, int personnel_max )
{

	s32  ln = ( p->gdi.text_sy / personnel_max );
	s32  sz = ln / 3;
	s32   x = p->x + p->gdi.text_x;
	s32   y = p->y + p->gdi.text_y + ( ln / 2 ) - ( sz / 2 ) + 1; y += index * ln;
	s32   z = p->gdi.text_fxsize1;

	n_bmp_circle( &game.bmp, x + z, y + z, sz, sz, sz, p->gdi.text_color_shadow );
	n_bmp_circle( &game.bmp, x    , y    , sz, sz, sz, p->gdi.text_color_main   );


	return;
}




void
n_nnrpg_window_tip( n_nnrpg_window *p, const n_game_chara *c, u32 color )
{

	p->gdi.sx                 = 0;
	p->gdi.sy                 = 0;
	p->gdi.style              = N_GDI_SMOOTH;
	p->gdi.layout             = 0;
	p->gdi.align              = 0;

	p->gdi.base_color_bg      = n_nnrpg_metric.color_trans;
	p->gdi.base_color_fg      = n_nnrpg_metric.color_trans;
	p->gdi.base_style         = N_GDI_BASE_SOLID;

	p->gdi.frame_style        = N_GDI_FRAME_NOFRAME;

	p->gdi.text               = p->msg;
	p->gdi.text_font          = n_project_stdfont();
	p->gdi.text_size          = n_nnrpg_metric.textsize;
	p->gdi.text_color_main    = n_bmp_white;
	p->gdi.text_color_contour = color;
	p->gdi.text_style         = N_GDI_TEXT_CONTOUR;
	p->gdi.text_fxsize1       = n_nnrpg_metric.zoom;
	p->gdi.text_fxsize2       = n_nnrpg_metric.zoom;

	n_gdi_bmp( &p->gdi, &p->bmp );


	p->sx = N_BMP_SX( &p->bmp );
	p->sy = N_BMP_SY( &p->bmp );
	p->x  = c->x + n_game_centering( c->sx, p->sx );
	p->y  = ( c->y + c->sy ) - ( p->sy / 2 );


	return;
}


