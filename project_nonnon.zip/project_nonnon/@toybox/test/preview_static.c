// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html



// [Mechanism]
//
//	Bitmap : ugly and heavier than StretchBlt()
//	Text   : Win9x has size limit




#include "../../nonnon/neutral/bmp/all.c"
#include "../../nonnon/neutral/txt.c"

#include "../../nonnon/win32/win.c"


#include "../../nonnon/project/macro.c"




static n_posix_char cmdline[ N_PATH_MAX ];

static n_bmp bmp;
static n_txt txt;




void
n_paint_preview_free( HWND hwnd, HWND hwnd_static )
{

	HBITMAP hbmp = (HBITMAP) n_win_message_send( hwnd_static, STM_GETIMAGE, IMAGE_BITMAP, 0 );


	if ( hbmp != NULL ) { n_win_bitmap_exit( hbmp ); }


	n_bmp_free( &bmp );
	n_txt_free( &txt );


	return;
}

void
n_paint_preview_init( HWND hwnd, HWND hwnd_static )
{

	n_paint_preview_free( hwnd, hwnd_static );


	// [!] : bitmap first

	if ( n_bmp_load( &bmp, cmdline ) )
	{

		n_win_style_del( hwnd_static, SS_BITMAP );

		if ( false == n_txt_load( &txt, cmdline ) )
		{
			SetWindowText( hwnd_static, txt.stream );
		}

		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );


		return;

	} else {

		n_win_style_add( hwnd_static, SS_BITMAP );

	}


	HDC hdc = GetDC( hwnd_static );

	BITMAPINFO bi = { N_BMP_INFOH( &bmp ), { { 0,0,0,0 } } };

	HBITMAP hbmp = CreateDIBitmap
	(
		hdc,
		&bi.bmiHeader,
		CBM_INIT,
		N_BMP_PTR( &bmp ),
		&bi,
		DIB_RGB_COLORS
	);

	ReleaseDC( hwnd_static, hdc );


	n_win_message_send( hwnd_static, STM_SETIMAGE, IMAGE_BITMAP, hbmp );


	{

		s32 desktopsx = GetSystemMetrics( SM_CXMAXIMIZED );
		s32 desktopsy = GetSystemMetrics( SM_CYMAXIMIZED );


		double ratio, ratio_x, ratio_y;

		n_win  maxclientsize;
		int    nwinset = N_WIN_SET_CALCONLY | N_WIN_SET_CLIPPING;

		s32    sx,sy;


		n_win_set( hwnd, &maxclientsize, desktopsx,desktopsy, nwinset );


		ratio_x = (double) maxclientsize.csx / N_BMP_SX( &bmp );
		ratio_y = (double) maxclientsize.csy / N_BMP_SY( &bmp );

		ratio   = n_posix_min_double( ratio_x, ratio_y );


		sx = N_BMP_SX( &bmp ) * ratio;
		sy = N_BMP_SY( &bmp ) * ratio;


		n_win_set( hwnd, NULL, sx,sy, N_WIN_SET_CENTERING );

	}


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hwnd_static;


	switch( msg ) {


	case WM_CREATE :


		// window

		n_win_init_literal( hwnd, "Preview", "", "" );

		n_win_gui_literal( hwnd, STATIC, "", &hwnd_static );


		// style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		// init

		n_win_commandline( cmdline );

		n_bmp_zero( &bmp );
		n_txt_zero( &txt );

		n_paint_preview_init( hwnd, hwnd_static );


		// display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :

		n_win_move_simple( hwnd_static, 0,0, LOWORD(lparam), HIWORD(lparam), false );
		n_win_refresh( hwnd_static, false );

	break;


	case WM_DROPFILES :

		n_win_dropfiles( hwnd, wparam, cmdline );

		n_paint_preview_init( hwnd, hwnd_static );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_paint_preview_free( hwnd, hwnd_static );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

