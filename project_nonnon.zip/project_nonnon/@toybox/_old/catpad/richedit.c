// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include <string.h>

#include <windows.h>
#include <richedit.h>




extern n_txt txt;


static char    n_viewer_fontsize;

static HMODULE n_viewer_hmodule = NULL;
static WNDPROC n_viewer_pfunc;




#define N_VIEWER_REFRESH( hwnd ) SendMessage( hwnd, WM_NULL, 0, 0 )

// internal
LRESULT CALLBACK
n_viewer_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	MSG struct_msg;

	int scroll;


	scrollflag = -1;


	switch(msg) {

	case WM_VSCROLL :

		scroll = SB_VERT;

	break;
	case WM_HSCROLL :

		scroll = SB_HORZ;

	break;

	case WM_MOUSEWHEEL :

//sprintf(str, "%d", (int) wparam);
//MessageBox(hwnd, str, "DEBUG", 0);


		// Win98   : doesn't wheel-scroll automatically
		// Win2000 : prevent smooth scroll


		if ( (int) wparam > 0 )
		{
			scroll = SB_VERT;

			msg        = WM_VSCROLL;
			wparam     = SB_LINEUP;
			lparam     = 0;

		} else
		if ( (int) wparam < 0 )
		{
			scroll = SB_VERT;

			msg        = WM_VSCROLL;
			wparam     = SB_LINEDOWN;
			lparam     = 0;
		}

	break;

	
	case WM_LBUTTONDBLCLK :

		// using WS_*SCROLL and SB_THUMBTRACK
		//
		// Win98 : over-scrolling at the last column

		PeekMessage(&struct_msg, NULL,0,0,PM_REMOVE);

		return 0;

	break;

	case WM_NULL :

		SetWindowText(hwnd, "");

		SendMessage(hwnd, EM_SETLIMITTEXT, 0, (LPARAM) txt.size);

		SetWindowText(hwnd, txt.ptr);

		SendMessage(hwnd, WM_VSCROLL, SB_ENDSCROLL, 0);
		SendMessage(hwnd, WM_HSCROLL, SB_ENDSCROLL, 0);

	break;

	} // switch


	if ( scroll != -1 )
	{

		// using WS_*SCROLL and SB_THUMBTRACK
		//
		// over-scrolling when pressing down/right arrow
		//
		// Win9x   : VERT and HORZ
		// Win2000 : HORZ only, but VERT is incorrect
		//
		// cannot know the needed nMax size
		//
		//	.nMax           : has previous value
		//	EM_GETLINECOUNT : returns invalid value
		//
		//	nMax is not "EM_GETLINECOUNT * step"

		// cannot know the line height
		//
		//	Win2000 : vertical spacing
		//	16pt =>  4px
		//	35pt => 10px


		SCROLLINFO si;
		int        step;

		//RECT       rect;


//sprintf(str, "%d", (int)SendMessage(hwnd, EM_GETLINECOUNT, 0,0) );
//SetWindowText( GetParent(hwnd), str);


		step = n_viewer_fontsize;


		ZeroMemory( &si, sizeof(SCROLLINFO) );

		si.cbSize = sizeof(SCROLLINFO);
		si.fMask  = SIF_ALL;

		GetScrollInfo(hwnd, scroll, &si);


		si.nMin = 0;


		switch( LOWORD(wparam) ) {

		case SB_LINEUP :

			si.nPos -= step;

		break;
		case SB_LINEDOWN :

			si.nPos += step;

		break;

		case SB_PAGEUP :

			si.nPos -= si.nPage;

		break;
		case SB_PAGEDOWN :

			si.nPos += si.nPage;

		break;

		case SB_TOP :

			si.nPos = si.nMin;

		break;
		case SB_BOTTOM :

			si.nPos = si.nMax;

		break;

		case SB_THUMBPOSITION :
		case SB_THUMBTRACK    :

			// using WS_*SCROLL and SB_THUMBTRACK
			//
			// Win98 : SB_THUMBPOSITION
			// 	mis-behave when a cursor in bottom-right 32x32

			si.nPos = HIWORD(wparam);

		break;

		} // switch


		if ( si.nPos < 0 )
		{
			si.nPos = 0;
		}
		if ( si.nPos >= ( si.nMax - si.nPage + 1 ) )
		{
			si.nPos = si.nMax - si.nPage + 1;
		}

//sprintf(str, "%d %d", si.nMax - si.nPage, si.nPos);
//SetWindowText( GetParent(hwnd), str);


		// using WS_*SCROLL and SB_THUMBTRACK
		//
		// PROBLEM : EM_SETSCROLLPOS : rich edit 3.0 or later
		//
		// Win2000 : cannot fix
		//	buggy behavior when VSCROLL at bottom
		//	force to put a first visible line on y=0


		if ( scroll == SB_VERT )
		{
			msg = WM_VSCROLL;
		} else
		if ( scroll == SB_HORZ )
		{
			msg = WM_HSCROLL;
		}
		wparam = MAKEWPARAM(SB_THUMBTRACK, si.nPos);
		CallWindowProc(n_viewer_pfunc, hwnd, msg, wparam, 0);

		SetScrollInfo(hwnd, scroll, &si, TRUE);


		PeekMessage(&struct_msg, NULL,0,0,PM_REMOVE);


		return 0;

	}


	return CallWindowProc(n_viewer_pfunc, hwnd, msg, wparam, lparam);
}

void
n_viewer_load(HWND hwnd, HWND *hwnd_ctl)
{

	if ( hwnd == NULL ) { return; }


	n_viewer_hmodule = LoadLibrary("riched32.dll");

	(*hwnd_ctl) = CreateWindowEx(
		WS_EX_CLIENTEDGE,
		"RICHEDIT",
		"",
		WS_CHILD       | WS_VISIBLE    |
		WS_VSCROLL     | WS_HSCROLL    | ES_AUTOHSCROLL |
		ES_MULTILINE   | ES_WANTRETURN |
		ES_READONLY    |
		ES_NOHIDESEL,
		0,0, 0,0,
		hwnd,
		(HMENU) NULL,
		GetModuleHandle(NULL),
		NULL 
	);
//if ( (*hwnd_ctl) == NULL ) { MessageBox(NULL, "RichEdit : Load", "DEBUG", 0); }


	n_viewer_pfunc = n_win_gui_subclass_set( (*hwnd_ctl), n_viewer_subclass);


	return;
}

void
n_viewer_font(HWND hwnd_ctl, HFONT hfont)
{

	// vertical spacing
	//
	//	Win2000 : by unknown calculation (maybe twips & float)
	//	Win95   : default is zero


	HWND hwnd = GetParent(hwnd_ctl);

	int i;

	int tmp;

	CHARFORMAT cf;
	PARAFORMAT pf;

	HDC   hdc;

	HFONT hfont_old;
	SIZE  size;


	hdc = GetDC(hwnd);


	hfont_old = SelectObject(hdc, hfont);

	GetTextExtentPoint32(hdc, "a", strlen("a"), &size);

	SelectObject(hdc, hfont_old);


	tmp = 1440 / GetDeviceCaps(hdc, LOGPIXELSY);


	ReleaseDC(hwnd, hdc);


	n_viewer_fontsize = size.cy;


	ZeroMemory( &cf, sizeof(CHARFORMAT) );
	cf.cbSize          = sizeof(CHARFORMAT);
	cf.dwMask          = CFM_EFFECTS | CFM_COLOR | CFM_SIZE | CFM_FACE | CFM_CHARSET;
	cf.dwEffects       = CFE_AUTOCOLOR;
	cf.yHeight         = n_viewer_fontsize * tmp;
	cf.yOffset         = 0;
	cf.bCharSet        = DEFAULT_CHARSET;
	cf.bPitchAndFamily = FIXED_PITCH | FF_SWISS;
	SendMessage(hwnd_ctl, EM_SETCHARFORMAT, (WPARAM) SCF_ALL, (LPARAM) &cf);


	ZeroMemory( &pf, sizeof(PARAFORMAT) );
	pf.cbSize          = sizeof(PARAFORMAT);
	pf.dwMask          = PFM_STARTINDENT | PFM_TABSTOPS;
	pf.dxStartIndent   = 4 * tmp;
	pf.cTabCount       = MAX_TAB_STOPS;

	// width * char_count
	tmp = ( (n_viewer_fontsize * tmp) / 2 ) * 8;

	i = 0;
	while( 1 )
	{
		pf.rgxTabs[i] = tmp * (i+1);

		i++;
		if ( i >= MAX_TAB_STOPS ) { break; }
	}
	SendMessage(hwnd_ctl, EM_SETPARAFORMAT, 0, (LPARAM) &pf);


	SendMessage( hwnd_ctl, WM_SETFONT, (WPARAM) hfont, false );


	return;
}

void
n_viewer_free(void)
{

	// after DestroyWindow()

	FreeLibrary(n_viewer_hmodule);


	return;
}

