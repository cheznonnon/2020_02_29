// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_DWM
#define _H_NONNON_WIN32_WIN_DWM




#include "../registry.c"
#include "../gdi/color.c"




bool
n_win_dwm_is_on( void )
{

	bool ret = false;


	// [!] : for compatibility layer support

	if ( false == n_sysinfo_version_vista_or_later() ) { return ret; }


	HMODULE hmod = LoadLibrary( n_posix_literal( "dwmapi.dll" ) );
	if ( hmod == NULL ) { return ret; }

	FARPROC func = GetProcAddress( hmod, "DwmIsCompositionEnabled" );
	if ( func != NULL )
	{
		if ( S_OK != func( &ret ) ) { ret = false; }
	}

	FreeLibrary( hmod );

/*
	HMODULE hmod = LoadLibrary( n_posix_literal( "UxTheme.dll" ) );
	if ( hmod == NULL ) { return ret; }

	FARPROC func = GetProcAddress( hmod, "IsCompositionActive" );
	if ( func != NULL )
	{
		ret = func();
	}

	FreeLibrary( hmod );
*/

	return ret;
}

#define n_win_dwm_transparent_on(  hwnd ) n_win_dwm_transparent_on_partial( hwnd, -1,-1,-1,-1 )
#define n_win_dwm_transparent_off( hwnd ) n_win_dwm_transparent_on_partial( hwnd,  0, 0, 0, 0 )

void
n_win_dwm_transparent_on_partial( HWND hwnd, int left, int top, int right, int bottom )
{

	// [Mechanism]
	//
	//	only black color will be handled as transparent
	//	NULL_BRUSH is meaningless
	//	UxTheme/Visual Style API is needed for alpha-blending
	//	almost controls are not supported this feature
	//
	//	you can use these techniques
	//
	//	[ WM_CREATE ]
	//	SetClassLong( hwnd, GCL_HBRBACKGROUND, (LONG) 0 );
	//
	//	[ WM_ERASEBKGND ]
	//	return TRUE;
	//
	//	[ WM_PAINT ]
	//	CreateSolidBrush( RGB( 0,0,0 ) );
	//
	//	[ WM_SETTINGCHANGE ]
	//	call this module again


	HMODULE hmod = LoadLibrary( n_posix_literal( "dwmapi.dll" ) );
	if ( hmod == NULL ) { return; }


	// [!] : uxtheme.h

	typedef struct _MARGINS {

		int cxLeftWidth;
		int cxRightWidth;
		int cyTopHeight;
	  	int cyBottomHeight;

	} MARGINS, *PMARGINS;


	FARPROC func = GetProcAddress( hmod, "DwmExtendFrameIntoClientArea" );
	if ( func != NULL )
	{

		MARGINS ms = { left, right, top, bottom };

		func( hwnd, &ms );

	}


	FreeLibrary( hmod );


	return;
}

u32
n_win_dwm_windowcolor( void )
{

	u32 fallback = n_gdi_systemcolor( COLOR_ACTIVECAPTION );
	u32 color    = fallback;


	if ( false == n_win_dwm_is_on() ) { return color; }


	// [x] : DwmGetColorizationColor() returns a how-to-use-this value

	if ( n_sysinfo_version_10_or_later() )
	{

		n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\DWM" );
		n_posix_char *section = n_posix_literal( "ColorPrevalence" );
		u32           onoff   = 0;

		DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &onoff, sizeof( u32 ) );
		if ( ( ret != ERROR_SUCCESS )||( onoff == 0 ) )
		{

			section = n_posix_literal( "ColorizationColor" );

			DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &color, sizeof( u32 ) );
			if ( ret != ERROR_SUCCESS ) { color = fallback; }

		} else {

			section = n_posix_literal( "AccentColor" );

			DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &color, sizeof( u32 ) );
			if ( ret != ERROR_SUCCESS )
			{

				color = fallback;

			} else {

				// [!] : format : ABGR

				int a = n_bmp_a( color );
				int r = n_bmp_r( color );
				int g = n_bmp_g( color );
				int b = n_bmp_b( color );

				color = n_bmp_argb( a,b,g,r );

			}
//if ( color != 0x00cca329 ) { n_posix_debug_literal( " ! " ); }
		}

	} else {

		n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\DWM" );
		n_posix_char *section = n_posix_literal( "ColorizationColor" );

		DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &color, sizeof( u32 ) );
		if ( ret != ERROR_SUCCESS ) { color = fallback; }

	}


	// [x] : alpha is used in many cases

	return n_bmp_alpha_visible_pixel( color );
}

bool
n_win_dwm_is_opaque( void )
{

	u32 onoff = true;


	if ( n_win_dwm_is_on() )
	{

		n_posix_char *subkey  = n_posix_literal( "Software\\Microsoft\\Windows\\DWM" );
		n_posix_char *section = n_posix_literal( "ColorizationOpaqueBlend" );

		DWORD ret = n_registry_read( HKEY_CURRENT_USER, subkey, section, &onoff, sizeof( u32 ) );

		if ( ret != ERROR_SUCCESS ) { onoff = true; }

	}


	return onoff;
}


#endif // _H_NONNON_WIN32_WIN_DWM

