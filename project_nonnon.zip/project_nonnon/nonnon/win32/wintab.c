// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




// [Mechanism]
//
//	[ How to Get ]
//
//	a : use "nonnon/_sdk/wintab/*" (these files are redistributable)
//	b : download from http://www.wacomeng.com/
//
//	[ Limitations ]
//
//	+ dynamic link only available
//	+ WINTABX.H is not used




#ifndef _H_NONNON_WIN32_WIN_WINTAB
#define _H_NONNON_WIN32_WIN_WINTAB




#include "../neutral/posix.c"




#include "../_sdk/wintab/wintab.h"

#define PACKETDATA    ( PK_CURSOR | PK_X | PK_Y | PK_BUTTONS | PK_NORMAL_PRESSURE | PK_ORIENTATION | PK_STATUS | PK_CURSOR )
#define PACKETMODE    PK_BUTTONS
#define NPACKETQSIZE  32

#include "../_sdk/wintab/pktdef.h"




typedef struct {

	HMODULE    hmod;

	FARPROC    WTOpen;
	FARPROC    WTClose;
	FARPROC    WTInfo;
	FARPROC    WTEnable;
	FARPROC    WTPacket;

	HCTX       hctx;
	LOGCONTEXT lc;
	PACKET     packet;

} n_wintab;




#define n_wintab_cursor_x( wt ) ( wt )->packet.pkX
#define n_wintab_cursor_y( wt ) ( wt )->packet.pkY


// [!] : pkStatus : TPS_* : TPS_INVERT is set when using eraser
// [!] : pkCursor : 1 = Pen : 2 = Eraser

#define n_wintab_pressure_get( wt ) ( wt )->packet.pkNormalPressure
#define n_wintab_tps_stat_get( wt ) ( wt )->packet.pkStatus
#define n_wintab_pen_type_get( wt ) ( wt )->packet.pkCursor

#define n_wintab_is_pen(     wt ) ( 1 == n_wintab_pen_type_get( wt ) )
#define n_wintab_is_eraser(  wt ) ( 2 == n_wintab_pen_type_get( wt ) )
#define n_wintab_is_pressed( wt ) (      n_wintab_pressure_get( wt ) )

int
n_wintab_pressure_max( n_wintab *wt )
{

	int ret = 0;

	if ( wt->WTInfo != NULL )
	{
		AXIS axis;
		wt->WTInfo( WTI_DEVICES, DVC_NPRESSURE, &axis );
		ret = axis.axMax;
	}


	return ret;
}




#define n_wintab_zero( wt ) ZeroMemory( wt, sizeof( n_wintab ) )

void
n_wintab_exit( n_wintab *wt )
{

	if ( wt == NULL ) { return; }


	if ( wt->WTClose != NULL )
	{
		wt->WTClose( &wt->hctx );
	}

	if ( wt->hmod != NULL )
	{
		FreeLibrary( wt->hmod );
	}

	ZeroMemory( wt, sizeof( n_wintab ) );


	return;
}

void
n_wintab_init( n_wintab *wt, HWND hwnd )
{

	if ( wt == NULL ) { return; }


	wt->hmod = LoadLibrary( n_posix_literal( "Wintab32.dll" ) );
	if ( wt->hmod == NULL )
	{
//n_posix_debug_literal( "LoadLibrary()" );

		return;
	}


#ifdef UNICODE

	wt->WTOpen   = GetProcAddress( wt->hmod, "WTOpenW"  );
	wt->WTInfo   = GetProcAddress( wt->hmod, "WTInfoW"  );

#else // #ifdef UNICODE

	wt->WTOpen   = GetProcAddress( wt->hmod, "WTOpenA"  );
	wt->WTInfo   = GetProcAddress( wt->hmod, "WTInfoA"  );

#endif // #ifdef UNICODE

	wt->WTClose  = GetProcAddress( wt->hmod, "WTClose"  );
	wt->WTEnable = GetProcAddress( wt->hmod, "WTEnable" );
	wt->WTPacket = GetProcAddress( wt->hmod, "WTPacket" );

	if (
		( wt->WTOpen   == NULL )
		||
		( wt->WTClose  == NULL )
		||
		( wt->WTInfo   == NULL )
		||
		( wt->WTEnable == NULL )
		||
		( wt->WTPacket == NULL )
		||
		( 0 == wt->WTInfo( WTI_DEFSYSCTX, 0, &wt->lc ) )
	)
	{

		n_wintab_exit( wt );

		return;
	}


	wt->lc.lcPktData   = PACKETDATA;
	wt->lc.lcPktMode   = PACKETMODE;
	wt->lc.lcOptions  |= CXO_MESSAGES;
	wt->lc.lcMoveMask  = PACKETDATA;

	wt->hctx = (HCTX) wt->WTOpen( hwnd, &wt->lc, TRUE );
	if ( wt->hctx == NULL )
	{
//n_posix_debug_literal( "WTOpen()" );

		n_wintab_exit( wt );

		return;
	}


	return;
}

void
n_wintab_packet_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, const n_wintab *wt )
{

	switch( msg ) {


	case WT_PACKET :
//SetWindowText( hwnd, "WT_PACKET" );

		if ( wt->WTPacket != NULL )
		{
			wt->WTPacket( (HCTX) lparam, wparam, &wt->packet );
		}

	break;


	} // switch


	return;
}

#endif // _H_NONNON_WIN32_WIN_WINTAB

