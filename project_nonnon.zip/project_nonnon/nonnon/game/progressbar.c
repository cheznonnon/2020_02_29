// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_GAME_PROGRESSBAR
#define _H_NONNON_WIN32_GAME_PROGRESSBAR




#include "../neutral/bmp/all.c"


#include "./helper.c"




// [!] : currently handled as hidden parameters


// [!] : zero == OFF

static u32  n_game_progressbar_animation_interval = 10;


#define N_GAME_PROGRESSBAR_ANIMATION_OFF     0
#define N_GAME_PROGRESSBAR_ANIMATION_ON_UP   1
#define N_GAME_PROGRESSBAR_ANIMATION_ON_DOWN 2

static int  n_game_progressbar_animation = N_GAME_PROGRESSBAR_ANIMATION_OFF;


static bool n_game_progressbar_no_round  = false;
static int  n_game_progressbar_round_div =     2;
static int  n_game_progressbar_border    =     1;




bool
n_game_progressbar_stripe_detect( s32 x, s32 y, s32 animation, s32 stripe )
{

	// [Mechanism]
	//
	//	Formula   : ( ( n % stripe_size ) < ( stripe_size / 2 ) )
	//	animation : 0 to stripe


	s32 n = x + y;


	// [Patch] : top-left corner is not rendered

	n += stripe;


	if ( n_game_progressbar_animation == N_GAME_PROGRESSBAR_ANIMATION_ON_UP   )
	{
		n -= animation;
	} else
	if ( n_game_progressbar_animation == N_GAME_PROGRESSBAR_ANIMATION_ON_DOWN )
	{
		n += animation;
	}


	if ( ( n % stripe ) < ( stripe / 2 ) ) { return true; }


	return false;
}

#define N_GAME_PROGRESSBAR_HORIZONTAL 0
#define N_GAME_PROGRESSBAR_VERTICAL   1

#define n_game_progressbar_vert( b, x,y,sx,sy, fg,bg, pc, s ) n_game_progressbar( b, x,y,sx,sy, fg,bg, pc, s, N_GAME_PROGRESSBAR_VERTICAL   )
#define n_game_progressbar_horz( b, x,y,sx,sy, fg,bg, pc, s ) n_game_progressbar( b, x,y,sx,sy, fg,bg, pc, s, N_GAME_PROGRESSBAR_HORIZONTAL )

void
n_game_progressbar
(
	n_bmp *bmp,
	s32 x, s32 y, s32 sx, s32 sy,
	u32         fg,
	u32         bg,
	double percent,
	int     stripe,
	int       mode
)
{

	if ( n_bmp_error_clipping( bmp,NULL, &x,&y,&sx,&sy, NULL,NULL ) ) { return; }


	if ( percent > 100 ) { percent = 100; }


	const double pc = percent * 0.01;


	if ( stripe == 0 )
	{

		s32 fx,fy,fsx,fsy;
		s32 tx,ty,tsx,tsy;


		if ( mode == N_GAME_PROGRESSBAR_HORIZONTAL )
		{

			fx  = x;
			fy  = y;
			fsx = (s32) ( (double) sx * pc );
			fsy = sy;
			tx  = x + fsx;
			ty  = y;
			tsx = sx - fsx;
			tsy = sy;

		} else {

			fx  = x;
			fy  = y;
			fsx = sx;
			fsy = (s32) ( (double) sy * pc );
			tx  = x;
			ty  = y + fsy;
			tsx = sx;
			tsy = sy - fsy;

		}

		n_bmp_box( bmp, fx,fy,fsx,fsy, fg );
		n_bmp_box( bmp, tx,ty,tsx,tsy, bg );

	} else {

		// Debug Center

		//n_game_progressbar_animation = N_GAME_PROGRESSBAR_ANIMATION_ON_DOWN;
		//n_game_hwndprintf_literal( "%d", n_game_progressbar_animation );
		//percent = 0;


		s32 bar_sx = (s32) ( pc * sx );
		s32 bar_sy = (s32) ( pc * sy );


		if ( mode == N_GAME_PROGRESSBAR_HORIZONTAL )
		{
			sx = n_posix_max_s32( sx, sy );
		} else {
			sy = n_posix_max_s32( sx, sy );
		}


		if ( n_game_progressbar_round_div < 2 ) { n_game_progressbar_round_div = 2; }


		const s32    minim  = n_posix_min_s32( sx, sy );
		//const s32    maxim  = n_posix_max_s32( sx, sy );
		const double sugar  = (double) 1.0 / minim;
		const s32    half   = minim / 2;
		const s32    round  = ( minim / n_game_progressbar_round_div ) + ( minim % 2 );
		const double border = 0.75 * n_game_progressbar_border;
		const double brdr_f = 0.25 * border;
		const double brdr_t = 1.75 * border;


		static int animation = 0;


		double pipe = 0.0;


		s32 tx = 0;
		s32 ty = 0;
		while( 1 )
		{

			u32    color = bg;
			bool   onoff = false;
			double coeff;

			if ( n_game_progressbar_no_round )
			{

				coeff = 1.0;

				if ( percent != 0 )
				{

					double d = 1.0;

					if ( mode == N_GAME_PROGRESSBAR_HORIZONTAL )
					{
						onoff = ( tx < bar_sx );
					} else {
						onoff = ( ty < bar_sy );
					}

					if ( onoff ) { color = n_bmp_blend_pixel( bg, fg, d ); }

				}

			} else {

				n_bmp_roundrect_detect_coeff( tx,ty,sx,sy, round, &coeff );

				if ( percent != 0 )
				{

					double d;

					if ( mode == N_GAME_PROGRESSBAR_HORIZONTAL )
					{
						onoff = n_bmp_roundrect_detect_coeff( tx + round, ty, bar_sx + round, sy, round, &d );
					} else {
						onoff = n_bmp_roundrect_detect_coeff( tx, ty + round, sx, bar_sy + round, round, &d );
					}

					if ( onoff ) { color = n_bmp_blend_pixel( bg, fg, d ); }

				}

			}


			// [!] : stripe main

			if ( n_game_progressbar_stripe_detect( tx,ty, animation, stripe ) )
			{
				color = n_bmp_blend_pixel( color, n_bmp_white, 0.25 );
			}


			// [!] : pipe-like effect

			if (
				( ( mode == N_GAME_PROGRESSBAR_HORIZONTAL )&&( ty <= half ) )
				||
				( ( mode == N_GAME_PROGRESSBAR_VERTICAL   )&&( tx <= half ) )
			)
			{
				color = n_bmp_blend_pixel( color, n_bmp_white, 0.5 - pipe );
			} else {
				color = n_bmp_blend_pixel( color, n_bmp_white, pipe - 0.5 );
			}


			// [!] : border

			if ( n_game_progressbar_no_round == false )
			{
				if ( ( coeff >= brdr_f )&&( coeff <= brdr_t ) )
				{
					color = n_bmp_blend_pixel( color, n_bmp_black + 1, 0.1 );
				}
			}


			if ( n_bmp_ptr_is_accessible( bmp, tx + x, ty + y ) )
			{
				u32 c;
				n_bmp_ptr_get_fast( bmp, tx + x, ty + y, &c     );

				color = n_bmp_blend_pixel( c, color, coeff );

				n_bmp_ptr_set_fast( bmp, tx + x, ty + y,  color );
			}


			if ( mode == N_GAME_PROGRESSBAR_VERTICAL ) { pipe += sugar; }

			tx++;
			if ( tx >= sx )
			{

				tx = 0;

				ty++;
				if ( ty >= sy ) { break; }

				if ( mode == N_GAME_PROGRESSBAR_HORIZONTAL ) { pipe += sugar; } else { pipe = 0; }

			}
		}


		static u32 timer = 0;

		if (
			( n_game_progressbar_animation_interval != 0 )
			&&
			( n_game_timer( &timer, n_game_progressbar_animation_interval ) )
		)
		{
			animation++;
			if ( animation >= stripe ) { animation = 0; }
		}

	}


	return;
}


#endif // _H_NONNON_WIN32_GAME_PROGRESSBAR

